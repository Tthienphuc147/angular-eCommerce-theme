import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-info-bar',
  templateUrl: './info-bar.component.html',
  styleUrls: ['./info-bar.component.sass']
})
export class InfoBarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
