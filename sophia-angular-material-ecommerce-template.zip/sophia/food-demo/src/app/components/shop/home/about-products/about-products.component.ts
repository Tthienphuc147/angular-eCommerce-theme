import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-about-products',
  templateUrl: './about-products.component.html',
  styleUrls: ['./about-products.component.sass']
})
export class AboutProductsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
