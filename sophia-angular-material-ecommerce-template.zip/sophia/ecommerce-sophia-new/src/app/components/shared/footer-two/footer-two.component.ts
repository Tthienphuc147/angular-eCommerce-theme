import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-footer-two',
  templateUrl: './footer-two.component.html',
  styleUrls: ['./footer-two.component.sass']
})
export class FooterTwoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
