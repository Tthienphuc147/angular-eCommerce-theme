import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-categories-section',
  templateUrl: './categories-section.component.html',
  styleUrls: ['./categories-section.component.sass']
})
export class CategoriesSectionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
